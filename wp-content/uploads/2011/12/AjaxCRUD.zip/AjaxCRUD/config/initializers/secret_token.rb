# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
AjaxCRUD::Application.config.secret_token = '64829a6c25e50c9900694ee258bc238b59e56c68dac321812f1df02e0dc62945bc52c72c423efdedd7c3e02fc2c927227643d9aed2edb442758d3131c30c13f8'
