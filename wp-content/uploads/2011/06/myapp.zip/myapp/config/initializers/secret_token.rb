# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Myapp::Application.config.secret_token = 'c00033f5f3b784d601d402f28ac51dd55ad004ad56183035d45fb9a249c5b347300df18f37041c435155fcd900bd837d9a6b2e0e23c2e6e2d07d3e67e45dad48'
