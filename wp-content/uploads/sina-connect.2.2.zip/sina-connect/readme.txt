﻿=== Plugin Name ===
Contributors: denishua
Donate link: http://fairyfish.net/donate/
Tags: Sina,Connect
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 2.2

使用新浪微博瓣账号登陆你的 WordPress 博客，博主可以同步日志到新浪微博，用户可以同步留言到新浪微博。

== Description ==

使用新浪微博瓣账号登陆你的 WordPress 博客，并且留言使用新浪微博的头像。博主可以同步日志到新浪微博，用户可以同步留言到新浪微博。

详细介绍： http://fairyfish.net/2010/06/08/sina-connect/

== Installation ==

上传激活即可。详细安装请点击： http://fairyfish.net/2010/06/08/sina-connect/


== Changelog ==

= 2.2 - 修正同步到新浪微博的问题。

= 2.1 - 修正一个登陆之后还有按钮的 bug

= 2.0 - 增加登陆和注册框的连接按钮，增加同步日志和留言功能。

= 1.0 - 初始版本